from clamour import start_clamour_non_blocking, ContextManagedQueue
import sys
import time

if __name__ == "__main__":
    # An argument of anything else than 0 sets debug to True.
    sound = False
    if len(sys.argv) > 1:
        sound = bool(int(sys.argv[1]))

    with ContextManagedQueue() as pose_queue:
        start_clamour_non_blocking(pose_queue, sound)

        while True:
            print("Doing other stuff")
            time.sleep(1)